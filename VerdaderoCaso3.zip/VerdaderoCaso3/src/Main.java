import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.Queue;
import java.util.stream.Collectors;

public class Main {

	public static void main(String[] args) throws IOException {
		Main instancia = new Main();
		try ( 
				InputStreamReader is= new InputStreamReader(System.in);
				BufferedReader br = new BufferedReader(is);
				) { 

			String line = br.readLine();
			//numero de casos
			int casos = Integer.parseInt(line);
			line = br.readLine();
			for(int i=0;i<casos && line!=null && line.length()>0 && !"0".equals(line);i++) {
				System.out.println(line);
				String  respuestas = instancia.procesar(line);
				line = br.readLine();	
			}
		}

	}


	/**
	 * 
	 * @param cadena es la cadena que se tiene que verificar si tiene solucion
	 * @return
	 */
	public String procesar(String t)
	{

		//primero definimos una cadena completa
		char[] cadenaCaracteres;
		cadenaCaracteres= t.toCharArray();

		//inicializo la subcadena
		String s ="";

		ArrayList<Character> subCadenaCaracteres = new ArrayList<Character>();
		ArrayList<Character> subCadenaCaracteresCopia = new ArrayList<Character>();

		//recorremos la cadena de entrada t
		for (int i =0; i<cadenaCaracteres.length;i++)
		{

			//sub cadena que se concatena a la derecha
			s+=Character.toString(cadenaCaracteres[i]);
			//aqui tengo el arreglo de la subcadena


			subCadenaCaracteresCopia.add(cadenaCaracteres[i]);
			subCadenaCaracteres.addAll(subCadenaCaracteresCopia);

			// de la subcadena resultante, puedo obtener una sub cadena de t usando todos mis elementos y quitando 1?

			int k=0;
			int remover1Vez=0;
			boolean sirve=true;
			String posibleSecuencia = "";
			String posibleRespuesta= s;
			//mientras j+1 no se salga de la cadena, sirva y la subCadena s no este vacia 
			
			for(int j=i+1; j<cadenaCaracteres.length&&sirve==true&&subCadenaCaracteres.isEmpty()!=true;j++)	
			{
				//si estoy en la ultima posicion del s
				//hay que volver K 0 de nuevo cada iteracion.y volver remover1Vez0


				if(k==subCadenaCaracteres.size()-1) {
					//si remover1vez es igual a 0 y ya estoy en la ultima posicion.
					if(remover1Vez==0) {
						posibleSecuencia+=Character.toString(subCadenaCaracteres.get(k));
						metodoCorrimiento(subCadenaCaracteres, subCadenaCaracteres.get(k));
						k=-1;
						//if(subCadenaCaracteres.isEmpty()==false) {
							//j--;
						//}
						remover1Vez=0;

					} else if(Character.compare(subCadenaCaracteres.get(k),cadenaCaracteres[j])!=0) {
						sirve=false;
					}
					else {
						posibleRespuesta+=Character.toString(subCadenaCaracteres.get(k));
						k=-1;
						remover1Vez=0;
					}

				}
				
				else//si estoy en cualquiera menos la ultima posicion de s
				{
					if(Character.compare(subCadenaCaracteres.get(k),cadenaCaracteres[j])==0)
					{
						posibleRespuesta+=Character.toString(subCadenaCaracteres.get(k));
						//no haga nada
					}
					else if((Character.compare(subCadenaCaracteres.get(k+1),cadenaCaracteres[j])==0)&&remover1Vez==0)
					{
						posibleSecuencia+=Character.toString(subCadenaCaracteres.get(k));
						metodoCorrimiento(subCadenaCaracteres, subCadenaCaracteres.get(k));
						posibleRespuesta+=Character.toString(subCadenaCaracteres.get(k));
						remover1Vez++;


					}
					else 
					{
						sirve=false;
					}
				}
				k++;
			}

			if(sirve==false)
			{

			}
			else if(subCadenaCaracteres.isEmpty())
			{
			}
			else if(posibleRespuesta.equals(t)==true)
			{
				System.out.println(s+" CON CADENA "+posibleSecuencia);
				return s+" CON CADENA "+posibleSecuencia;
			}

			subCadenaCaracteres.removeAll(subCadenaCaracteres);

		}
		System.out.println("no existe");
		return "NO EXISTE";
	}


	public void metodoCorrimiento(ArrayList<Character> entrada, char condicion)
	{
		entrada.removeIf(x-> x.equals(condicion));
	}

}





